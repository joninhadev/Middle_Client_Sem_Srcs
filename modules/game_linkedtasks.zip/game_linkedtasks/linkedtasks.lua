-- game_linkedtasks / linkedtasks.lua

linkedTasksWindow = nil
local taskButton  = nil

local OPCODE_LINKED_TASKS = 101
local categories = {"Iniciante", "Intermediaria", "Hard"}
local CARD_WIDTH = 100

-- -- Outfit helpers ------------------------------------------
local function normalizeOutfit(outfit)
    if not outfit then return {type = 0} end
    if outfit.lookType then
        outfit.type   = outfit.lookType
        outfit.head   = outfit.lookHead   or 0
        outfit.body   = outfit.lookBody   or 0
        outfit.legs   = outfit.lookLegs   or 0
        outfit.feet   = outfit.lookFeet   or 0
        outfit.addons = outfit.lookAddons or 0
        outfit.mount  = outfit.lookMount  or 0
    end
    return outfit
end

-- -- Module lifecycle ----------------------------------------
function init()
    connect(g_game, {
        onGameStart = onGameStart,
        onGameEnd   = destroy
    })

    linkedTasksWindow = g_ui.displayUI('linkedtasks')
    if linkedTasksWindow then
        linkedTasksWindow:setVisible(false)
        setupCategoryCombo()
    end

    taskButton = modules.client_topmenu.addRightGameToggleButton(
        'linkedTasksButton',
        tr('Linked Tasks'),
        '/images/topbuttons/questlog',
        toggle
    )
    taskButton:setOn(false)

    ProtocolGame.registerExtendedOpcode(OPCODE_LINKED_TASKS, onExtendedOpcode)
end

function terminate()
    disconnect(g_game, {
        onGameStart = onGameStart,
        onGameEnd   = destroy
    })
    ProtocolGame.unregisterExtendedOpcode(OPCODE_LINKED_TASKS, onExtendedOpcode)

    if taskButton then
        taskButton:destroy()
        taskButton = nil
    end
    destroy()
end

function onGameStart()
    destroy()
    linkedTasksWindow = g_ui.displayUI('linkedtasks')
    if linkedTasksWindow then
        linkedTasksWindow:setVisible(false)
        setupCategoryCombo()
    end
end

function destroy()
    if linkedTasksWindow then
        linkedTasksWindow:destroy()
        linkedTasksWindow = nil
    end
end

-- -- Category ComboBox ---------------------------------------
function setupCategoryCombo()
    if not linkedTasksWindow then return end
    local combo = linkedTasksWindow:recursiveGetChildById('categoryCombo')
    if not combo then return end

    combo:clearOptions()
    for _, cat in ipairs(categories) do
        combo:addOption(cat)
    end
    combo:setCurrentIndex(1)

    combo.onOptionChange = function(widget, text, data)
        sendCategoryRequest(text)
    end
end

function sendCategoryRequest(category)
    if not g_game.isOnline() then return end
    local proto = g_game.getProtocolGame()
    if proto then
        proto:sendExtendedOpcode(OPCODE_LINKED_TASKS,
            json.encode({ action = "info", category = category }))
    end
end

-- -- Toggle / Show / Hide ------------------------------------
function toggle()
    if not linkedTasksWindow then return end
    if linkedTasksWindow:isVisible() then hide() else show() end
end

function show()
    if not linkedTasksWindow then return end
    linkedTasksWindow:show()
    linkedTasksWindow:raise()
    linkedTasksWindow:focus()
    if taskButton then taskButton:setOn(true) end

    local combo = linkedTasksWindow:recursiveGetChildById('categoryCombo')
    local cat = combo and combo:getCurrentOption() and combo:getCurrentOption().text or "Iniciante"
    sendCategoryRequest(cat)
end

function hide()
    if not linkedTasksWindow then return end
    linkedTasksWindow:hide()
    if taskButton then taskButton:setOn(false) end
end

-- -- Network (generic action sender) -------------------------
function sendAction(actionType)
    if not g_game.isOnline() then return end
    local proto = g_game.getProtocolGame()
    if not proto then return end

    local combo = linkedTasksWindow and linkedTasksWindow:recursiveGetChildById('categoryCombo')
    local cat = "Iniciante"
    if combo and combo:getCurrentOption() then
        cat = combo:getCurrentOption().text
    end

    proto:sendExtendedOpcode(OPCODE_LINKED_TASKS,
        json.encode({ action = actionType, category = cat }))
end

function onExtendedOpcode(protocol, opcode, buffer)
    local ok, data = pcall(json.decode, buffer)
    if ok and data and data.action == "update" then
        updateUI(data)
    end
end

-- -- Task Card builder ---------------------------------------
local function createTaskCard(parent, taskInfo, isCurrent, isDone, isLocked, progress)
    local card = g_ui.createWidget('TaskCardWidget', parent)

    if isCurrent and not isDone then
        card:setOn(true)
    end

    local lockIcon = card:getChildById('lockIcon')
    if lockIcon then
        lockIcon:setVisible(isLocked)
    end

    local creatureBox = card:getChildById('creatureBox')
    if creatureBox then
        creatureBox:setOutfit(normalizeOutfit(taskInfo.outfit))
        creatureBox:setAnimate(true)
        if isLocked then
            creatureBox:setOpacity(0.25)
        elseif isDone then
            creatureBox:setOpacity(0.50)
        end
    end

    local nameLabel = card:getChildById('nameLabel')
    if nameLabel then
        nameLabel:setText(taskInfo.name or "???")
        if isDone then
            nameLabel:setColor("#55FF55")
        elseif isCurrent then
            nameLabel:setColor("#FFFFFF")
        elseif isLocked then
            nameLabel:setColor("#666666")
        else
            nameLabel:setColor("#AAAAAA")
        end
    end

    -- Progress bar only (no text on cards - count shown in detail panel)
    local progressLabel = card:getChildById('progressLabel')
    if progressLabel then progressLabel:setText("") end

    local barBg   = card:getChildById('barBackground')
    local barFill = barBg and barBg:getChildById('barFill')

    if isCurrent and not isDone then
        if barFill then
            local prog  = progress or 0
            local total = taskInfo.count or 1
            local pct   = math.min(prog / total, 1.0)
            local maxW  = barBg:getWidth()
            if maxW <= 0 then maxW = CARD_WIDTH - 8 end
            barFill:setWidth(math.max(1, math.floor(maxW * pct)))
            if pct >= 1.0 then
                barFill:setBackgroundColor("#55FF55")
            elseif pct >= 0.5 then
                barFill:setBackgroundColor("#FFAA22")
            else
                barFill:setBackgroundColor("#4488FF")
            end
        end
    else
        if barBg then barBg:setVisible(false) end
    end

    local badgeLabel = card:getChildById('badgeLabel')
    if badgeLabel then
        if isDone then
            badgeLabel:setText("Completed")
            badgeLabel:setColor("#55FF55")
        elseif isCurrent then
            badgeLabel:setText("Active")
            badgeLabel:setColor("#FFFFFF")
        elseif isLocked then
            badgeLabel:setText("Locked")
            badgeLabel:setColor("#666666")
        else
            badgeLabel:setText("")
        end
    end
end

-- -- Detail panel builder ------------------------------------
local function updateDetailPanel(data)
    if not linkedTasksWindow then return end

    local detailContent = linkedTasksWindow:recursiveGetChildById('detailContent')
    if not detailContent then return end

    detailContent:destroyChildren()

    -- If no active/completed task, show placeholder
    if not data.state or data.state == "locked" or data.state == "all_done" then
        local lbl = g_ui.createWidget('Label', detailContent)
        lbl:setText("Selecione uma task ativa.")
        lbl:setTextAlign(AlignCenter)
        lbl:setColor("#666666")
        lbl:setFont("verdana-11px-rounded")
        lbl:setHeight(20)
        lbl:setBackgroundColor("alpha")
        return
    end

    -- Creatures header
    local creaturesHeader = g_ui.createWidget('Label', detailContent)
    creaturesHeader:setText("Criaturas:")
    creaturesHeader:setTextAlign(AlignLeft)
    creaturesHeader:setColor("#CCCCCC")
    creaturesHeader:setFont("verdana-11px-rounded")
    creaturesHeader:setHeight(16)
    creaturesHeader:setBackgroundColor("alpha")

    -- Creature list
    if data.targetsDetail then
        for _, tgt in ipairs(data.targetsDetail) do
            local row = g_ui.createWidget('Label', detailContent)
            row:setText("  " .. tgt.name .. " x" .. tgt.count)
            row:setTextAlign(AlignLeft)
            row:setColor("#AAAAAA")
            row:setFont("verdana-11px-rounded")
            row:setHeight(14)
            row:setBackgroundColor("alpha")
        end
    end

    -- Spacer
    local spacer1 = g_ui.createWidget('Panel', detailContent)
    spacer1:setHeight(6)
    spacer1:setBackgroundColor("alpha")

    -- Progress count
    local progressCount = g_ui.createWidget('Label', detailContent)
    local prog  = data.progress or 0
    local total = 0
    if data.targetsDetail then
        for _, tgt in ipairs(data.targetsDetail) do
            total = total + tgt.count
        end
    end
    progressCount:setText("Progresso: " .. prog .. " of " .. total)
    progressCount:setTextAlign(AlignLeft)
    progressCount:setColor("#FFFFFF")
    progressCount:setFont("verdana-11px-rounded")
    progressCount:setHeight(16)
    progressCount:setBackgroundColor("alpha")

    -- XP Reward
    local xpLabel = g_ui.createWidget('Label', detailContent)
    xpLabel:setText("XP: " .. (data.xpReward or 0))
    xpLabel:setTextAlign(AlignLeft)
    xpLabel:setColor("#FFDD44")
    xpLabel:setFont("verdana-11px-rounded")
    xpLabel:setHeight(16)
    xpLabel:setBackgroundColor("alpha")

    -- Spacer
    local spacer2 = g_ui.createWidget('Panel', detailContent)
    spacer2:setHeight(6)
    spacer2:setBackgroundColor("alpha")

    -- Fixed reward
    local fixedHeader = g_ui.createWidget('Label', detailContent)
    fixedHeader:setText("Recompensa fixa:")
    fixedHeader:setTextAlign(AlignLeft)
    fixedHeader:setColor("#CCCCCC")
    fixedHeader:setFont("verdana-11px-rounded")
    fixedHeader:setHeight(16)
    fixedHeader:setBackgroundColor("alpha")

    if data.fixedRewardId and data.fixedRewardId > 0 then
        local rewardRow = g_ui.createWidget('Panel', detailContent)
        rewardRow:setHeight(36)
        rewardRow:setBackgroundColor("alpha")
        rewardRow:setLayout(UIHorizontalLayout.create(rewardRow))

        local itemWidget = g_ui.createWidget('Item', rewardRow)
        itemWidget:setVirtual(true)
        itemWidget:setItemId(data.fixedRewardId)
        itemWidget:setItemCount(data.fixedRewardCount or 1)
        itemWidget:setWidth(34)
        itemWidget:setHeight(34)
        itemWidget:setMarginLeft(4)

        local countLabel = g_ui.createWidget('Label', rewardRow)
        countLabel:setText("x" .. (data.fixedRewardCount or 1))
        countLabel:setTextAlign(AlignLeft)
        countLabel:setColor("#FFFFFF")
        countLabel:setFont("verdana-11px-rounded")
        countLabel:setWidth(60)
        countLabel:setHeight(34)
        countLabel:setMarginLeft(6)
        countLabel:setBackgroundColor("alpha")
    end
end

-- -- Update entire UI from server payload --------------------
function updateUI(data)
    if not linkedTasksWindow then return end

    -- Sync ComboBox
    local combo = linkedTasksWindow:recursiveGetChildById('categoryCombo')
    if combo and data.category then
        local current = combo:getCurrentOption()
        if not current or current.text ~= data.category then
            combo:setCurrentOption(data.category, true)
        end
    end

    -- Task cards
    local container = linkedTasksWindow:recursiveGetChildById('taskListContainer')
    local scrollbar = linkedTasksWindow:recursiveGetChildById('taskScrollbar')

    if container then
        container:destroyChildren()

        if data.tasks then
            local foundCurrent = false
            for _, taskInfo in ipairs(data.tasks) do
                local isCurrent = (taskInfo.id == data.currentTaskId)
                local isDone    = false
                local isLocked  = false

                if isCurrent then
                    foundCurrent = true
                    isDone = (data.state == "all_done")
                elseif not foundCurrent then
                    isDone = true
                else
                    isLocked = true
                end

                createTaskCard(container, taskInfo, isCurrent, isDone, isLocked, data.progress)
            end
        end

        if scrollbar then
            local totalCards = data.tasks and #data.tasks or 0
            local totalWidth = totalCards * (CARD_WIDTH + 6)
            local overflow   = math.max(0, totalWidth - container:getWidth())
            scrollbar:setRange(0, overflow)
            scrollbar.onValueChange = function(_, value)
                local first = container:getChildByIndex(1)
                if first then first:setMarginLeft(-value) end
            end
        end
    end

    -- Reward slots
    local rewardsPanel = linkedTasksWindow:recursiveGetChildById('rewardsPanel')
    if rewardsPanel then
        for i = 1, 4 do
            local slot = rewardsPanel:getChildById('rewardSlot' .. i)
            if slot then
                if data.rewards and data.rewards[i] then
                    slot:setItemId(data.rewards[i])
                    slot:setItemCount(data.rewardsCount and data.rewardsCount[i] or 1)
                else
                    slot:setItemId(0)
                end
            end
        end
    end

    -- Detail panel (right side)
    updateDetailPanel(data)

    -- Action button
    local actionButton = linkedTasksWindow:recursiveGetChildById('actionButton')
    if actionButton then
        if data.state == "completed" then
            actionButton:setText(tr("Claim Reward"))
            actionButton.onClick = function() sendAction("claim") end
            actionButton:setEnabled(true)
        elseif data.state == "active" then
            actionButton:setText(tr("Em progresso ..."))
            actionButton.onClick = nil
            actionButton:setEnabled(false)
        elseif data.state == "locked" then
            local txt = data.reqLevel
                and ("Locked (Level " .. data.reqLevel .. ")")
                or "Locked"
            actionButton:setText(tr(txt))
            actionButton.onClick = nil
            actionButton:setEnabled(false)
        elseif data.state == "available" then
            actionButton:setText(tr("Iniciar Task"))
            actionButton.onClick = function() sendAction("start") end
            actionButton:setEnabled(true)
        elseif data.state == "all_done" then
            actionButton:setText(tr("Todas completas!"))
            actionButton.onClick = nil
            actionButton:setEnabled(false)
        else
            actionButton:setText(tr("N/A"))
            actionButton.onClick = nil
            actionButton:setEnabled(false)
        end
    end
end